#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <color.h>
#define SPEED 500000
int main(){
red();
printf("abc\n");

 int i=0;
 for(i=0;i<100;i++){
   system("clear");
   red();
   usleep(SPEED);
   system("figlet PHAR");
   green();
   printf("\n");
   usleep(SPEED);
   system("figlet MA");
   yellow();
   usleep(SPEED);
   system("figlet CIE");
   usleep(SPEED);

 }
reset();

}
