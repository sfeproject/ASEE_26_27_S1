#include <ncurses.h>
#include <unistd.h>

// Animation 1 : Effet machine à écrire (de gauche à droite)
void animation_machine_a_ecrire() {
    char *texte = "PHARMACIE";
    int y = 10;
    int x = 30;

    while (1) {
        clear();
        mvprintw(2, 2, "Appuyez sur n'importe quelle touche pour revenir au menu.");
        attron(COLOR_PAIR(1) | A_BOLD);

        for (int i = 0; texte[i] != '\0'; i++) {
            timeout(0); // Non bloquant pour détecter une touche
            if (getch() != ERR) {
                attroff(COLOR_PAIR(1) | A_BOLD);
                return; // Retourne au menu
            }
            mvaddch(y, x + i, texte[i]);
            refresh();
            usleep(150000); // 150 ms de pause par lettre
        }
        attroff(COLOR_PAIR(1) | A_BOLD);

        // Pause d'une seconde avant de boucler l'animation
        timeout(1000); 
        if (getch() != ERR) return;
    }
}

// Animation 2 : Clignotement multicolore
void animation_clignotante() {
    char *texte = "*** PHARMACIE ***";
    int y = 10;
    int x = 28;
    int color_index = 1;

    while (1) {
        timeout(0);
        if (getch() != ERR) return; // Retourne au menu

        clear();
        mvprintw(2, 2, "Appuyez sur n'importe quelle touche pour revenir au menu.");

        // Active la couleur et le clignotement
        attron(COLOR_PAIR(color_index) | A_BLINK | A_BOLD);
        mvprintw(y, x, "%s", texte);
        attroff(COLOR_PAIR(color_index) | A_BLINK | A_BOLD);

        refresh();

        // Change de couleur en boucle (de 1 à 4)
        color_index++;
        if (color_index > 4) color_index = 1;

        usleep(300000); // 300 ms de pause
    }
}

int main() {
    // Initialisation de ncurses
    initscr();
    start_color();
    noecho();
    cbreak();
    keypad(stdscr, TRUE);
    curs_set(0);

    // Définition de paires de couleurs
    init_pair(1, COLOR_GREEN, COLOR_BLACK);
    init_pair(2, COLOR_RED, COLOR_BLACK);
    init_pair(3, COLOR_YELLOW, COLOR_BLACK);
    init_pair(4, COLOR_CYAN, COLOR_BLACK);

    char *choices[] = {
        "1. Animation Machine à écrire (de gauche à droite)",
        "2. Animation Clignotante multicolore",
        "3. Quitter"
    };
    int n_choices = 3;
    int highlight = 0;
    int c;

    while (1) {
        clear();
        mvprintw(2, 4, "=== MENU DES ANIMATIONS PHARMACIE ===");
        mvprintw(3, 4, "Utilisez les flèches HAUT/BAS et validez avec ENTREE.");

        // Affichage du menu
        for (int i = 0; i < n_choices; i++) {
            if (i == highlight) {
                attron(A_REVERSE); // Surbrillance
            }
            mvprintw(6 + i, 6, "%s", choices[i]);
            if (i == highlight) {
                attroff(A_REVERSE);
            }
        }
        refresh();

        // Lecture bloquante pour naviguer tranquillement dans le menu
        timeout(-1); 
        c = getch();
        
        switch (c) {
            case KEY_UP:
                highlight--;
                if (highlight < 0) highlight = n_choices - 1;
                break;
            case KEY_DOWN:
                highlight++;
                if (highlight >= n_choices) highlight = 0;
                break;
            case '\n': // Touche Entrée
                if (highlight == 0) {
                    animation_machine_a_ecrire();
                } else if (highlight == 1) {
                    animation_clignotante();
                } else if (highlight == 2) {
                    endwin();
                    return 0;
                }
                break;
        }
    }

    endwin();
    return 0;
}
