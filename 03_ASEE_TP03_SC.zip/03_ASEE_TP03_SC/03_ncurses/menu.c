#include <ncurses.h>

int main() {
    // Initialisation de ncurses
    initscr();
    noecho();             // Neffiche pas les touches tapees
    cbreak();             // Desactive le buffering de ligne
    keypad(stdscr, TRUE); // Active les touches speciales (fleches)
    curs_set(0);          // Masque le curseur clignotant

    // Liste des options du menu
    char *choices[] = {
        "1. Lancer une action",
        "2. Afficher les parametres",
        "3. Quitter"
    };
    int n_choices = 3;
    int highlight = 0;
    int choice = -1;
    int c;

    while(1) {
        clear(); // Efface l'ecran a chaque tour de boucle

        // En-tete du menu
        mvprintw(1, 4, "=== MON SUPER MENU EN MODE TEXTE ===");
        mvprintw(2, 4, "Utilisez les fleches HAUT/BAS et validez avec ENTREE.\n");

        // Affichage des options avec surbrillance pour l'option selectionnee
        for(int i = 0; i < n_choices; i++) {
            if(i == highlight) {
                attron(A_REVERSE); // Inverse les couleurs (surbrillance)
            }
            mvprintw(4 + i, 6, "%s", choices[i]);
            if(i == highlight) {
                attroff(A_REVERSE);
            }
        }

        refresh(); // Rafraichit l'affichage

        // Lecture de la touche utilisateur
        c = getch();
        switch(c) {
            case KEY_UP:
                highlight--;
                if(highlight < 0)
                    highlight = n_choices - 1; // Boucle vers le bas
                break;
            case KEY_DOWN:
                highlight++;
                if(highlight >= n_choices)
                    highlight = 0; // Boucle vers le haut
                break;
            case '\n': // Touche Entree
                choice = highlight;
                break;
            default:
                break;
        }

        // Action selon le choix valide
        if(choice != -1) {
            if(choice == 2) { // Option "Quitter"
                break;
            }

            // Affiche un message temporaire pour les autres choix
            clear();
            mvprintw(4, 4, "Vous avez choisi : %s", choices[choice]);
            mvprintw(6, 4, "Appuyez sur une touche pour revenir au menu...");
            refresh();
            getch();

            choice = -1; // Reinitialise le choix pour continuer la boucle
        }
    }

    // Restauration du terminal d'origine
    endwin();
    return 0;
}
